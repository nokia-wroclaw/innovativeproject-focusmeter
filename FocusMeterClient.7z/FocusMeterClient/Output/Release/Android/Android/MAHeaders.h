#define LOCAL_FILES_BIN 1
#define BEEP_WAV 2
